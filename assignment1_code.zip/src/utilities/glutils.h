#pragma once

#include "mesh.h"

unsigned int generateBuffer(Mesh &mesh);